class RED:
    def __init__(self):
        self.pos = None
        self.force = None
        self.efficiency = None


class BLUE:
    def __init__(self):
        self.pos = None
        self.force = None
        self.efficiency = None


class BLOCK:
    def __init__(self):
        self.pos = None