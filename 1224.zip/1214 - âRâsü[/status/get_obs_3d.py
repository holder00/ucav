# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 19:27:31 2021

@author: Takumi
"""

import numpy as np
import copy

# def get_state(env,uav,position,distances):
#     # uav_state = np.zeros(env.observation_space.shape[1])
#     uav_state = {}
#     # if uav.faction == "blue":
#     #     uav_state = env.obs_dict.sample()
#     # elif uav.faction == "red":
#     #     uav_state = env.obs_dict_red.sample()
#     uav_state["hitpoint"] = np.array([uav.hitpoint])

#     uav_state["mrm_num"] = uav.mrm_num
#     if uav.inrange:
#         uav_state["inrange"] = np.array([0])
#     else:
#         uav_state["inrange"] = np.array([1])
#     if uav.detect_launch_ML:
#         uav_state["detect"] = np.array([0])
#     else:
#         uav_state["detect"] = np.array([1])
#     aa = -(uav.psi + uav.ops_az())
#     if aa > np.pi:
#         aa = aa - 2*np.pi
#     if aa < -np.pi:
#         aa = aa + 2*np.pi
#     uav_state["tgt_psi_x"] = np.array([np.cos(aa)])
#     uav_state["tgt_psi_y"] = np.array([np.sin(aa)])
#     aa = -(uav.gam + uav.ops_gam())
#     if aa > np.pi:
#         aa = aa - 2*np.pi
#     if aa < -np.pi:
#         aa = aa + 2*np.pi
#     aa = -aa
#     uav_state["tgt_gam_x"] = np.array([np.cos(aa)])
#     uav_state["tgt_gam_y"] = np.array([np.sin(aa)])    

#     # uav_state["tgt_psi_x"] = np.array([np.cos(uav.ops_az())])
#     # uav_state["tgt_psi_y"] = np.array([np.sin(uav.ops_az())])

#     # uav_state["tgt_gam_x"] = np.array([np.cos(uav.ops_gam())])
#     # uav_state["tgt_gam_y"] = np.array([np.sin(uav.ops_gam())])

#     uav_state["self_pos_x"] = np.array([position[0]])/env.WINDOW_SIZE_lat
#     uav_state["self_pos_y"] = np.array([position[1]])/env.WINDOW_SIZE_lon
#     uav_state["self_pos_z"] = np.array([position[2]])/env.WINDOW_SIZE_alt

#     uav_state["distances"] = distances/(env.WINDOW_SIZE_lat*3)
#     # act_num = len(env.action_dict_c['blue_' + str(uav.id)])
#     if uav.faction == "blue":
#         # act = env.action_dict_c['blue_' + str(uav.id)]
#         # uav_state.update(act)
#         # if uav.role == "shooter":
#         #     uav_state["role"] = 0
#         # else:
#         #     uav_state["role"] = 1
#         uav_state["vector_psi_x"] = np.array([uav.psi/(np.pi)])
#         # uav_state["vector_psi_y"] = np.array([np.sin(uav.psi)])
#         uav_state["vector_gam_x"] = np.array([uav.gam/(np.pi/2)])
#         # uav_state["vector_gam_y"] = np.array([np.sin(uav.gam)])
#         uav_state["velocity"] = np.array([uav.V/340.0])
#         uav_state["tgt_id"] = uav.tgt.id
        
#         # uav_state["phi_x"] = np.array([np.cos(uav.phi)])
#         # uav_state["phi_y"] = np.array([np.sin(uav.phi)])

#     return uav_state

def get_state_blue(env,uav,position,distances):
    harf = lambda val:2*val-1
    lat_norm = lambda val:harf((val+1)/3)
    # uav_state = np.zeros(env.observation_space.shape[1])
    uav_state = {}
    # if uav.faction == "blue":
    #     uav_state = env.obs_dict.sample()
    # elif uav.faction == "red":
    #     uav_state = env.obs_dict_red.sample()
    uav_state["hitpoint"] = np.array([harf(uav.hitpoint)])

    uav_state["mrm_num"] = np.array([harf(uav.mrm_num/2)])
    if uav.inrange:
        uav_state["inrange"] = np.array([harf(0)])
    else:
        uav_state["inrange"] = np.array([harf(1)])
    if uav.detect_launch_ML:
        uav_state["detect"] = np.array([harf(0)])
    else:
        uav_state["detect"] = np.array([harf(1)])
    aa = -(uav.psi + uav.ops_az())
    if aa > np.pi:
        aa = aa - 2*np.pi
    if aa < -np.pi:
        aa = aa + 2*np.pi
    uav_state["tgt_psi_x"] = np.array([np.cos(aa)])
    uav_state["tgt_psi_y"] = np.array([np.sin(aa)])
    aa = -(uav.gam + uav.ops_gam())
    if aa > np.pi:
        aa = aa - 2*np.pi
    if aa < -np.pi:
        aa = aa + 2*np.pi
    aa = -aa
    uav_state["tgt_gam_x"] = np.array([np.cos(aa)])
    uav_state["tgt_gam_y"] = np.array([np.sin(aa)])    

    # uav_state["tgt_psi_x"] = np.array([np.cos(uav.ops_az())])
    # uav_state["tgt_psi_y"] = np.array([np.sin(uav.ops_az())])

    # uav_state["tgt_gam_x"] = np.array([np.cos(uav.ops_gam())])
    # uav_state["tgt_gam_y"] = np.array([np.sin(uav.ops_gam())])

    uav_state["self_pos_x"] = np.array([lat_norm(position[0]/env.WINDOW_SIZE_lat)])
    uav_state["self_pos_y"] = np.array([harf(position[1]/env.WINDOW_SIZE_lon)])
    uav_state["self_pos_z"] = np.array([harf(position[2]/env.WINDOW_SIZE_alt)])

    uav_state["distances"] = harf(distances/(env.WINDOW_SIZE_lat*3))
    # act_num = len(env.action_dict_c['blue_' + str(uav.id)])

    # act = env.action_dict_c['blue_' + str(uav.id)]
    # uav_state.update(act)
    # if uav.role == "shooter":
    #     uav_state["role"] = 0
    # else:
    #     uav_state["role"] = 1
    uav_state["vector_psi_x"] = np.array([np.cos(uav.psi)])
    uav_state["vector_psi_y"] = np.array([np.sin(uav.psi)])
    uav_state["vector_gam_x"] = np.array([np.cos(uav.gam)])
    uav_state["vector_gam_y"] = np.array([np.sin(uav.gam)])
    uav_state["velocity"] = np.array([harf(uav.V/340.0)])
    uav_state["tgt_id"] = np.array([harf(uav.tgt.id)])
    uav_state["fire"] = np.array([harf(uav.cool_down/uav.cool_down_limit)])
        

    return uav_state

def get_state_red(env,uav,position,distances):
    harf = lambda val:2*val-1
    lat_norm = lambda val:harf((val+1)/3)
    # uav_state = np.zeros(env.observation_space.shape[1])
    uav_state = {}
    # if uav.faction == "blue":
    #     uav_state = env.obs_dict.sample()
    # elif uav.faction == "red":
    #     uav_state = env.obs_dict_red.sample()
    uav_state["hitpoint"] = np.array([harf(uav.hitpoint)])
    uav_state["self_pos_x"] = np.array([lat_norm(position[0]/env.WINDOW_SIZE_lat)])
    uav_state["self_pos_y"] = np.array([harf(position[1]/env.WINDOW_SIZE_lon)])
    uav_state["self_pos_z"] = np.array([harf(position[2]/env.WINDOW_SIZE_alt)])
    uav_state["velocity"] = np.array([harf(uav.V/340.0)])
    uav_state["distances"] = harf(distances/(env.WINDOW_SIZE_lat*3))
    return uav_state



def get_obs(env):
    obs = {}
    for i in range(env.blue_num):
        obs['blue_' + str(i)] = {}
        obs['blue_' + str(i)]["blues"] = {}
        obs['blue_' + str(i)]["reds"] = {}

    observation = {}
    observation["blues"] = {}
    observation["reds"] = {}
    obs_blues = {}
    position = np.zeros([env.blue_num+env.red_num,3])
    for i in range(env.blue_num):
        position[i] = env.blue[i].pos

    for i in range(env.red_num):
        position[i+env.blue_num] = env.red[i].pos
    distances = distances_calc(position)

    for i in range(env.blue_num):
        uav_id = 0
        # if not env.blue[i].hitpoint == 0:
        # obs['blue_' + str(i)]= env.observation_space.sample()
        for j in range(env.blue_num):
            if i == j:
                obs['blue_' + str(i)]["blues"]["self"] = get_state_blue(env,env.blue[j],position[j],distances[j])
            else:
                obs['blue_' + str(i)]["blues"]["blue_0"] = get_state_blue(env,env.blue[j],position[j],distances[j])
                uav_id = uav_id +1
        for j in range(env.red_num):
            obs['blue_' + str(i)]["reds"]["red_" + str(j)] = get_state_red(env,env.red[j],position[j+env.blue_num],distances[j+env.blue_num])

    return obs

# def get_state(env,uav,position,distances):
#     uav_state = np.zeros(env.observation_space.shape[1])
#     uav_state[0] = uav.hitpoint
#     uav_state[1] = uav.mrm_num
#     if uav.inrange:
#         uav_state[2] = 0
#     else:
#         uav_state[2] = 1
#     if uav.detect_launch_ML:
#         uav_state[3] = 0
#     else:
#         uav_state[3] = 1
#     uav_state[4] = np.cos(uav.ops_az())
#     uav_state[5] = np.sin(uav.ops_az())
#     # if uav.faction == "blue":
#     #     print(uav.faction,uav.pos,np.rad2deg([uav.psi,uav.gam,uav.ops_az(),uav.ops_gam()]))
#     # if uav.faction == "red":
#     #     print(uav.faction,uav.pos,np.rad2deg([uav.psi,uav.gam,uav.ops_az(),uav.ops_gam()]))
#     uav_state[6] = np.cos(uav.ops_gam())
#     uav_state[7] = np.sin(uav.ops_gam())

#     uav_state[8] = np.cos(uav.psi)
#     uav_state[9] = np.sin(uav.psi)

#     uav_state[10] = np.cos(uav.gam)
#     uav_state[11] = np.sin(uav.gam)

#     uav_state[12:15] = position/(np.array([env.WINDOW_SIZE_lat,env.WINDOW_SIZE_lon,env.WINDOW_SIZE_alt]))

#     act_num = 7
#     if uav.faction == "blue" and not uav.hitpoint == 0:
#         # print(act_num)
#         # print((env.action_dict_c['blue_' + str(uav.id)]))
#         act = env.action_dict_c['blue_' + str(uav.id)]
#         uav_state[15:15+act_num] = np.array([act["tgt_id"],
#                                               act["fire"],
#                                               act["vector_psi_x"],
#                                               act["vector_psi_y"],
#                                               act["vector_gam_x"],
#                                               act["vector_gam_y"],
#                                               act["velocity"]])
#     else:
#         uav_state[15:15+act_num] = -np.ones(act_num)

#     uav_state[15+act_num:] = distances/(env.WINDOW_SIZE_lat*3)

#     return uav_state

# # def get_state(env,uav,position,distances):
# #     # uav_state = np.zeros(env.observation_space.shape[1])
# #     uav_state = {}
# #     uav_state["hitpoint"] = uav.hitpoint
# #     uav_state["mrm_num"] = uav.mrm_num
# #     if uav.inrange:
# #         uav_state["inrange"] = 0
# #     else:
# #         uav_state["inrange"] = 1
# #     if uav.detect_launch_ML:
# #         uav_state["detect"] = 0
# #     else:
# #         uav_state["detect"] = 1
# #     uav_state["tgt_psi_x"] = np.cos(uav.ops_az())
# #     uav_state["tgt_psi_y"] = np.sin(uav.ops_az())

# #     uav_state["tgt_gam_x"] = np.cos(uav.ops_gam())
# #     uav_state["tgt_gam_y"] = np.sin(uav.ops_gam())

# #     uav_state["self_pos_x"] = position[0]
# #     uav_state["self_pos_y"] = position[1]
# #     uav_state["self_pos_z"] = position[2]
# #     uav_state["distances"] = distances

# #     act_num = len(env.action_dict_c['blue_' + str(uav.id)])
# #     if uav.faction == "blue" and not uav.hitpoint == 0:
# #         act = env.action_dict_c['blue_' + str(uav.id)]
# #         uav_state.update(act)

# #         # uav_state[11:11+act_num] = np.array([act["tgt_id"],act["fire"],
# #         #                                     act["vector_psi_x"],act["vector_psi_y"],
# #         #                                     act["vector_gam_x"],act["vector_gam_y"],
# #         #                                     act["velocity"]])
# #     else:
# #         # uav_state.update(act)
# #         # uav_state[11:11+act_num] = -np.ones(act_num)
# #         pass


# #     return uav_state
# def get_obs(env):
#     obs = {}
#     observation = np.zeros(env.observation_space.shape)
#     position = np.zeros([env.blue_num+env.red_num,3])
#     for i in range(env.blue_num):
#         position[i] = env.blue[i].pos

#     for i in range(env.red_num):
#         position[i+env.blue_num] = env.red[i].pos
#     distances = distances_calc(position)

#     for i in range(env.blue_num):
#         # 状態の作成
#         if not env.blue[i].hitpoint == 0:
#             observation[i,:] = get_state(env,env.blue[i],position[i],distances[i])


#     for i in range(env.red_num):
#         # 状態の作成
#         if not env.red[i].hitpoint == 0:
#             observation[i+env.blue_num,:] = get_state(env,env.red[i],position[i+env.blue_num],distances[i+env.blue_num])

#     for i in range(env.blue_num):
#         obs['blue_' + str(i)] = np.vstack([observation[i,:],np.delete(observation,i,0)]).astype(np.float32)

#     return obs



def distances_calc(position):
    tmp_index = np.arange(position.shape[0])
    xx, yy = np.meshgrid(tmp_index, tmp_index)
    distances = np.linalg.norm(position[xx]-position[yy], axis=2)


    return distances