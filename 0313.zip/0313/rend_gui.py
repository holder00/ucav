# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 22:21:54 2022

@author: Takumi
"""
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import numpy as np
import pickle
from utility.result_env import render_env
import time
# from result_env import render_env
class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        steps = 14*0+8
        f = open(str(steps)+"_"+"blue"+"_hist"+".pkl",mode="rb")
        self.blue_hist = pickle.load(f)
        f.close()
        f = open(str(steps)+"_"+"red"+"_hist"+".pkl",mode="rb")
        self.red_hist = pickle.load(f)
        f.close()
        f = open(str(steps)+"_"+"mrm"+"_hist"+".pkl",mode="rb")
        self.mrm_hist = pickle.load(f)
        f.close()
        f = open("info"+".pkl",mode="rb")
        self.info = pickle.load(f)
        f.close()
        self.time_max = self.mrm_hist.shape[0]
        self.plot_radar = True

        self.master = master
        self.master.title('Matplotlib in tkinter')
        self.pack()
        self.create_widgets()
        self.start_up()
        self.draw_plot()

    def create_widgets(self):
        self.canvas_frame = tk.Frame(self.master)
        self.canvas_frame.pack(side=tk.TOP)
        self.control_frame = tk.Frame(self.master)
        self.control_frame.pack(side=tk.BOTTOM)
        self.radar_button = tk.Button(self.control_frame, text="Radar",command=self.switch_radar)
        self.radar_button.pack(side=tk.RIGHT)
        self.elev_v = tk.DoubleVar()
        self.elev_scale = tk.Scale(self.control_frame,
            variable=self.elev_v,
            from_=-90,
            to=90,
            resolution=1,
            length = 50,
            orient=tk.VERTICAL,
            command=self.draw_plot)
        self.elev_scale.pack(side=tk.RIGHT)
        
        self.az_v = tk.DoubleVar()
        self.az_scale = tk.Scale(self.control_frame,
            variable=self.az_v,
            from_=-180,
            to=180,
            resolution=1,
            length = 50,
            orient=tk.VERTICAL,
            command=self.draw_plot)
        self.az_scale.pack(side=tk.RIGHT)
        self.right_button = tk.Button(self.control_frame, text="▶",command=self.right_button)
        self.right_button.pack(side=tk.RIGHT)       
        self.left_button = tk.Button(self.control_frame, text="◀",command=self.left_button)
        self.left_button.pack(side=tk.LEFT)

        self.canvas = FigureCanvasTkAgg(fig1, self.canvas_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # self.toolbar = NavigationToolbar2Tk(self.canvas, self.canvas_frame)
        # self.toolbar.update()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.x_v = tk.DoubleVar()
        self.x_scale = tk.Scale(self.control_frame,
            variable=self.x_v,
            from_=1,
            to=self.time_max,
            resolution=1,
            length = 500,
            orient=tk.HORIZONTAL,
            command=self.draw_plot)
        self.x_scale.pack(anchor=tk.NW)

        self.y_v = tk.DoubleVar()
        self.y_scale = tk.Scale(self.control_frame,
            variable=self.y_v,
            from_=1,
            to=self.time_max,
            resolution=10,
            length = 500,
            orient=tk.HORIZONTAL,
            command=self.draw_plot)
        self.y_scale.pack(anchor=tk.NW)

    def start_up(self):
        self.x_v.set(1.0)
        self.y_v.set(20.0)
        self.elev_v.set(90)
        self.az_v.set(-90)
        
    def switch_radar(self):
        if self.plot_radar:
            self.plot_radar = False
        else:
            self.plot_radar = True
        self.draw_plot()
    def right_button(self):
        self.x_v.set(self.x_v.get()+1.0)
        self.draw_plot()
    def left_button(self):
        self.x_v.set(self.x_v.get()-1.0)
        self.draw_plot()
            
    def plot_result(self,t,status_num,w):
        global ax, plt
        plt.clf()
        elev = self.elev_v.get()
        azim = self.az_v.get()
        if t == 1:
            num = int((np.shape(self.mrm_hist)[0])/status_num)
            for i in range(num):
                hist = self.mrm_hist[0,:]
                ax=render_env.rend_3d_mod3(t,hist[i*status_num:(i+1)*status_num],"k",1,self.info,i,w,self.plot_radar,elev,azim)
        else:
            num = int((np.shape(self.mrm_hist)[1])/status_num)
            for i in range(num):
                hist = self.mrm_hist[0:int(t),:]
                ax=render_env.rend_3d_mod3(t,hist[:,i*status_num:(i+1)*status_num],"k",1,self.info,i,w,self.plot_radar,elev,azim)
        if t == 1:
            num = int((np.shape(self.red_hist)[0])/status_num)
            for i in range(num):
                hist = self.red_hist[0,:]
                ax=render_env.rend_3d_mod3(t,hist[i*status_num:(i+1)*status_num],"r",1,self.info,i,w,self.plot_radar,elev,azim)
        else:
            num = int((np.shape(self.red_hist)[1])/status_num)
            for i in range(num):
                hist = self.red_hist[0:int(t),:]
                ax=render_env.rend_3d_mod3(t,hist[:,i*status_num:(i+1)*status_num],"r",1,self.info,i,w,self.plot_radar,elev,azim)

        if t == 1:
            num = int((np.shape(self.blue_hist)[0])/status_num)
            for i in range(num):
                hist = self.blue_hist[0,:]
                ax=render_env.rend_3d_mod3(t,hist[i*status_num:(i+1)*status_num],"b",1,self.info,i,w,self.plot_radar,elev,azim)
        else:
            num = int((np.shape(self.blue_hist)[1])/status_num)
            for i in range(num):
                hist = self.blue_hist[0:int(t),:]
                ax=render_env.rend_3d_mod3(t,hist[:,i*status_num:(i+1)*status_num],"b",1,self.info,i,w,self.plot_radar,elev,azim)
        self.canvas.draw()
        plt.subplots_adjust(left=-0.1,right=1.1,bottom=-0.1,top=1.1)
        
    def draw_plot(self, event=None):
        t = self.x_v.get()
        status_num = 13
        # t = self.x_v.get()
        w = self.y_v.get()

        t = int(t)
        if t < 1:
            t = 1
        self.plot_result(t,status_num,w)

f = open("info"+".pkl",mode="rb")
info = pickle.load(f)
f.close()
plt.ioff()
fig1 = plt.figure(1,figsize=(8.0, 6.0))

# fig1 = Figure(figsize=(5, 5), dpi=100)
# ax = fig.add_subplot(111)
ax = fig1.gca(projection='3d')



# ax, = ax.plot([],[], 'green')

root = tk.Tk()
app = Application(master=root)
app.mainloop()