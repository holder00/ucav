# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 19:27:31 2021

@author: Takumi
"""

import numpy as np
import copy

def get_state(env,uav,position,distances):
    # uav_state = np.zeros(env.observation_space.shape[1])
    uav_state = {}
    if uav.faction == "blue":
        uav_state = env.obs_dict.sample()
    elif uav.faction == "red":
        uav_state = env.obs_dict_red.sample()
    uav_state["hitpoint"] = np.array([uav.hitpoint])

    uav_state["mrm_num"] = uav.mrm_num
    if uav.inrange:
        uav_state["inrange"] = 0
    else:
        uav_state["inrange"] = 1
    if uav.detect_launch_ML:
        uav_state["detect"] = 0
    else:
        uav_state["detect"] = 1
    uav_state["tgt_psi_x"] = np.array([np.cos(uav.ops_az())])
    uav_state["tgt_psi_y"] = np.array([np.sin(uav.ops_az())])
    
    uav_state["tgt_gam_x"] = np.array([np.cos(uav.ops_gam())])
    uav_state["tgt_gam_y"] = np.array([np.sin(uav.ops_gam())])
    
    uav_state["self_pos_x"] = np.array([position[0]])
    uav_state["self_pos_y"] = np.array([position[1]])
    uav_state["self_pos_z"] = np.array([position[2]])
    
    uav_state["distances"] = distances 
    act_num = len(env.action_dict_c['blue_' + str(uav.id)])
    if uav.faction == "blue" and not uav.hitpoint == 0:
        act = env.action_dict_c['blue_' + str(uav.id)]
        uav_state.update(act)

    return uav_state

def get_obs(env):
    obs = {}

    observation = {}
    observation["blues"] = {}
    observation["reds"] = {}
    obs_blues = {}
    position = np.zeros([env.blue_num+env.red_num,3])
    for i in range(env.blue_num):
        position[i] = env.blue[i].pos
        
    for i in range(env.red_num):
        position[i+env.blue_num] = env.red[i].pos
    distances = env.distances_calc(position)

    for i in range(env.blue_num):
        uav_id = 0
        obs['blue_' + str(i)]= env.observation_space.sample()   
        for j in range(env.blue_num):
            if i == j:
                obs['blue_' + str(i)]["blues"]["self"] = get_state(env,env.blue[j],position[j],distances[j])
            else:
                obs['blue_' + str(i)]["blues"]["blue_0"] = get_state(env,env.blue[j],position[j],distances[j])
                uav_id = uav_id +1
        for j in range(env.red_num):
            obs['blue_' + str(i)]["reds"]["red_" + str(j)] = get_state(env,env.red[j],position[j+env.blue_num],distances[j+env.blue_num])

    return obs