# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 14:08:55 2021

@author: OokiT1
"""
import numpy as np
import matplotlib.pyplot as plt
f = open('Train.ipynb', 'r',encoding='utf-8')
test_case = "役割選択"
datalist = f.readlines()
# print (datalist[0])
# print (datalist[1])
# print (datalist[2])

def parse_log(keyword):
    l_in = [s for s in datalist if keyword in s]
    res = np.zeros([len(l_in),2])
    res_2 = np.zeros([len(l_in),1])
    for i in range(len(l_in)):
        res[i,0] = i
    
        a = l_in[i].split(":") 
        a = a[1].split(" ")
        a = a[1].split('",')
        a = a[0].split('\\n')
        # a = a[0].strip()
        a[1] = float(a[0])
        # b = .split(" ")
        # a = b[0]
        res_2[i] = a[1]
    return res_2
    
# l_in2 = l_in.split(':')
res_mean = parse_log("episode_reward_mean")
res_max = parse_log("episode_reward_max")
res_min = parse_log("episode_reward_min")
f.close()
plt.plot(res_mean,label=test_case)
plt.plot(res_max,label=test_case)
# plt.plot(res_min,label=test_case)
# plt.legend([test_case], bbox_to_anchor=(1, 1), loc='upper right', borderaxespad=0, fontsize=18,prop={"family":"MS Gothic"})

plt.grid("on")
plt.savefig("reward_res.png")